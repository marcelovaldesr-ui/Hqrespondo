import io, re

# ---------------------------------------------------------------- 1) el helper
p='lib/equipo.ts'
s=io.open(p,encoding='utf-8').read()
ancla='''export interface ObjetivoSemana {'''
nuevo='''/**
 * Quién está haciendo esta petición, listo para guardar.
 *
 * Envuelve a `personaDeLogin` para que ningún endpoint tenga que acordarse de
 * traducir la cabecera. Antes media docena guardaba el login crudo ("hq_admin")
 * y otros el nombre del equipo ("Marcelo"), así que la misma persona aparecía
 * con dos identidades distintas según qué pantalla la registró.
 *
 * Devuelve `null` cuando no hay login. Eso pasa a propósito en las rutas que el
 * middleware deja pasar sin autenticar —/api/cola, /api/prospeccion, /api/hooks—
 * porque ahí no hay una persona: hay un cron. Quien necesite firmar igual usa
 * `quienEs(req) ?? "el agente"`, que es honesto en vez de atribuirle a alguien
 * una acción que no hizo.
 */
export function quienEs(req: Request): string | null {
  return personaDeLogin(req.headers.get("x-hq-user")) || null;
}

export interface ObjetivoSemana {'''
assert ancla in s, "no calzo el ancla en equipo.ts"
s=s.replace(ancla,nuevo,1)
io.open(p,'w',encoding='utf-8').write(s)
print("equipo.ts: quienEs() agregado")

# --------------------------------------------- 2) normalizar los 7 usos crudos
ARCHIVOS = [
    "app/api/clients/[id]/onboarding/route.ts",
    "app/api/decisiones/route.ts",
    "app/api/gastos/route.ts",
    "app/api/growth/calendar/route.ts",
    "app/api/growth/ideas/route.ts",
    "app/api/roadmap/route.ts",
    "app/api/roadmap/[id]/route.ts",
]
for f in ARCHIVOS:
    t=io.open(f,encoding='utf-8').read()
    assert 'req.headers.get("x-hq-user")' in t, f"{f}: no estaba el uso crudo"
    t=t.replace('req.headers.get("x-hq-user")','quienEs(req)')
    if 'from "@/lib/equipo"' not in t:
        t=t.replace('import { db } from "@/lib/db";',
                    'import { db } from "@/lib/db";\nimport { quienEs } from "@/lib/equipo";',1)
    assert 'from "@/lib/equipo"' in t, f"{f}: no se pudo insertar el import"
    io.open(f,'w',encoding='utf-8').write(t)
    print(f"  {f}: guarda el nombre del equipo, no el login")

# ------------------------------------------- 3) alta manual: firmar quién la hizo
p3='app/api/foco/nuevo/route.ts'
t=io.open(p3,encoding='utf-8').read()
t=t.replace('import { normalizarTelefono } from "@/lib/actividades";',
            'import { normalizarTelefono } from "@/lib/actividades";\nimport { quienEs } from "@/lib/equipo";',1)
v='''        // Queda anotado que lo puso una persona: si mañana se reimporta un CSV
        // que traiga esta misma empresa, se puede distinguir qué vino de dónde.
        fuente_url: "alta manual en HQ",'''
n='''        // Queda anotado que lo puso una persona: si mañana se reimporta un CSV
        // que traiga esta misma empresa, se puede distinguir qué vino de dónde.
        fuente_url: "alta manual en HQ",
        creado_por: quienEs(req) ?? "alta manual",'''
assert v in t
t=t.replace(v,n,1)
io.open(p3,'w',encoding='utf-8').write(t)
print("api/foco/nuevo: firma quien lo agrego")

# ------------------------------------- 4) PATCH de foco: firmar quien lo modifico
p4='app/api/foco/route.ts'
t=io.open(p4,encoding='utf-8').read()
t=t.replace('import { personaDeLogin } from "@/lib/equipo";',
            'import { personaDeLogin, quienEs } from "@/lib/equipo";',1)
v2='''    const upd: Record<string, unknown> = { updated_at: new Date().toISOString() };'''
n2='''    const upd: Record<string, unknown> = { updated_at: new Date().toISOString() };
    // Toda edición queda firmada sola. Antes se podía cambiar el teléfono o el
    // estado de un lead sin que quedara rastro de quién lo hizo.
    const quien = quienEs(req);
    if (quien) upd.actualizado_por = quien;'''
assert v2 in t
t=t.replace(v2,n2,1)
io.open(p4,'w',encoding='utf-8').write(t)
print("api/foco PATCH: firma quien lo modifico")

# ------------------------------------------ 5) bitacora: devolver el autor del alta
p5='app/api/foco/bitacora/route.ts'
t=io.open(p5,encoding='utf-8').read()
t=t.replace('.select("id,empresa,contacto,intentos,sin_contestar,ultimo_intento,ultimo_resultado,estado,recordatorio,proximo_paso,proximo_paso_at,created_at")',
            '.select("id,empresa,contacto,intentos,sin_contestar,ultimo_intento,ultimo_resultado,estado,recordatorio,proximo_paso,proximo_paso_at,created_at,creado_por,actualizado_por")',1)
t=t.replace('        creado: lead.created_at,',
            '        creado: lead.created_at,\n        creado_por: lead.creado_por,\n        actualizado_por: lead.actualizado_por,',1)
assert 'creado_por: lead.creado_por' in t
io.open(p5,'w',encoding='utf-8').write(t)
print("api/foco/bitacora: devuelve creado_por")

# ------------------------------------------------ 6) UI: mostrarlo en el historial
p6='components/BitacoraLead.tsx'
t=io.open(p6,encoding='utf-8').read()
v3='''  proximo_paso: string | null;
  proximo_paso_at: string | null;
};'''
n3='''  proximo_paso: string | null;
  proximo_paso_at: string | null;
  creado: string | null;
  creado_por: string | null;
};'''
assert v3 in t
t=t.replace(v3,n3,1)

v4='''      {/* ---------- Próximo paso ---------- */}'''
n4='''      {/* ---------- Quién lo agregó ---------- */}
      {resumen && (
        <div className="mt-1.5 text-[10.5px] text-ink-faint">
          {resumen.creado_por
            ? <>Agregado por <b className="text-ink-mut">{resumen.creado_por}</b></>
            : <>Origen desconocido (anterior al registro de autor)</>}
          {resumen.creado ? ` · ${new Date(resumen.creado).toLocaleDateString("es-CL")}` : ""}
        </div>
      )}

      {/* ---------- Próximo paso ---------- */}'''
assert v4 in t
t=t.replace(v4,n4,1)
io.open(p6,'w',encoding='utf-8').write(t)
print("BitacoraLead.tsx: muestra quien lo agrego")
