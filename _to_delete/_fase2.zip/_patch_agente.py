import io
p = 'lib/agenteTelefono.ts'
s = io.open(p, encoding='utf-8').read()

# 1) exportar la pasada de Maps, renombrada para que se entienda fuera del archivo
viejo1 = '''/** 1) ¿La persona tiene su propia ficha en Google Maps? */
async function porMapsDeLaPersona('''
nuevo1 = '''/**
 * 1) ¿La persona tiene su propia ficha en Google Maps?
 *
 * Exportada (25-ago-2026) para que la cascada de la Fase 2 pueda decidir
 * CUÁNDO llamarla. `buscarTelefonoDirecto` la corre siempre y de primera, pero
 * consume cupo de Places (1.000 gratis al mes); la cascada la deja para después
 * de la web, que es gratis, y se la salta cuando el cortacircuitos dice que no
 * queda cupo.
 */
export async function telefonoPorMapsDeLaPersona('''
assert viejo1 in s, "no calzo porMapsDeLaPersona"
s = s.replace(viejo1, nuevo1, 1)

# 2) exportar la búsqueda pública
viejo2 = '''/** 3) Búsqueda pública con IA, obligada a citar. */
async function porBusquedaPublica('''
nuevo2 = '''/**
 * 3) Búsqueda pública con IA, obligada a citar.
 *
 * Exportada por el mismo motivo que la de arriba: es el paso más caro y el que
 * más se puede equivocar, así que quien la llama tiene que poder decidir si
 * corresponde gastarla.
 */
export async function telefonoPorBusquedaPublica('''
assert viejo2 in s, "no calzo porBusquedaPublica"
s = s.replace(viejo2, nuevo2, 1)

# 3) actualizar las llamadas internas
s = s.replace('await porMapsDeLaPersona(entrada.persona', 'await telefonoPorMapsDeLaPersona(entrada.persona', 1)
s = s.replace('await porBusquedaPublica(\n', 'await telefonoPorBusquedaPublica(\n', 1)

assert 'porMapsDeLaPersona(entrada.persona' in s
io.open(p, 'w', encoding='utf-8').write(s)
print("agenteTelefono.ts: dos pasadas exportadas")
