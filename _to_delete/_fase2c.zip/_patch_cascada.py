import io
p='lib/cascada.ts'
s=io.open(p,encoding='utf-8').read()

# import
v='''import {
  proveedoresYaConsultados,'''
n='''import { decisorBuscable } from "@/lib/decisorBuscable";
import {
  proveedoresYaConsultados,'''
assert v in s
s=s.replace(v,n,1)

# guard antes de gastar
v2='''    // Sin nombre de decisor no hay a quién buscar. Es definitivo mientras no
    // aparezca el nombre: si aparece, se vuelve a encolar y se pregunta de nuevo.
    if (!e.decisor_nombre || !e.comuna) {
      return {
        encontrado: false,
        intentos: [{
          proveedor: "sin_decisor", resultado: "sin_dato", encontrado: false,
          respuesta: { motivo: !e.decisor_nombre ? "sin decisor_nombre" : "sin comuna" },
        }],
      };
    }'''
n2='''    // Sin nombre de decisor no hay a quién buscar. Es definitivo mientras no
    // aparezca el nombre: si aparece, se vuelve a encolar y se pregunta de nuevo.
    if (!e.decisor_nombre || !e.comuna) {
      return {
        encontrado: false,
        intentos: [{
          proveedor: "sin_decisor", resultado: "sin_dato", encontrado: false,
          respuesta: { motivo: !e.decisor_nombre ? "sin decisor_nombre" : "sin comuna" },
        }],
      };
    }

    // ---- 0-bis. ¿este decisor se puede buscar? ----
    // Va ANTES de cualquier proveedor, y esa posición es todo el punto: un
    // decisor falso cuesta una búsqueda de Gemini y una de Places, y si por
    // mala suerte alguna "encuentra" algo, ensucia la lista de llamadas con un
    // número que alguien va a marcar. Ver lib/decisorBuscable.ts para los
    // cuatro modos de falla que esto ataja y la medición que los encontró.
    const veredicto = decisorBuscable(e.razon_social, e.decisor_nombre, e.decisor_confianza);
    if (!veredicto.buscable) {
      console.log(`[cascada] ${e.rut} SALTADA · ${e.decisor_nombre} · ${veredicto.motivo}`);
      return {
        encontrado: false,
        intentos: [{
          proveedor: "decisor_no_buscable",
          resultado: "sin_dato",
          encontrado: false,
          respuesta: { decisor: e.decisor_nombre, razon_social: e.razon_social, motivo: veredicto.motivo },
        }],
      };
    }'''
assert v2 in s
s=s.replace(v2,n2,1)

# agregar decisor_confianza al select
v3='.select("rut,razon_social,comuna,telefono,telefono_directo,decisor_nombre,prospect_id,n_trabajadores")'
n3='.select("rut,razon_social,comuna,telefono,telefono_directo,decisor_nombre,decisor_confianza,prospect_id,n_trabajadores")'
assert v3 in s
s=s.replace(v3,n3,1)

v4='''  decisor_nombre: string | null;
  prospect_id: string | null;'''
n4='''  decisor_nombre: string | null;
  decisor_confianza: string | null;
  prospect_id: string | null;'''
assert v4 in s
s=s.replace(v4,n4,1)

io.open(p,'w',encoding='utf-8').write(s)
print("cascada.ts: guardia de decisor instalada antes de gastar")
