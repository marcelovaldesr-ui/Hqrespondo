import io

# ---------- 1) agenteTelefono: devolver el nombre tal como está en la fuente ----------
p='lib/agenteTelefono.ts'
s=io.open(p,encoding='utf-8').read()

v1='''export interface HallazgoTelefono {
  telefono: string;
  tipo: TipoNumero;
  /** Qué tan seguro es que sea de la persona y no del mesón. */
  confianza: "alta" | "media" | "baja";
  fuente: string;
  comoLoSupe: string;
}'''
n1='''export interface HallazgoTelefono {
  telefono: string;
  tipo: TipoNumero;
  /** Qué tan seguro es que sea de la persona y no del mesón. */
  confianza: "alta" | "media" | "baja";
  fuente: string;
  comoLoSupe: string;
  /**
   * El nombre COMPLETO tal como lo publica la fuente, cuando la fuente lo
   * trae. El que sacamos de la razón social del SII viene truncado —"Jorge
   * Bellolio" donde Maps dice "Jorge Adolfo Bellolio Messer"—, así que esta
   * versión es mejor para pedir por la persona al llamar.
   */
  nombreEnLaFuente?: string;
}'''
assert v1 in s
s=s.replace(v1,n1,1)

v2='''      fuente: `Google Maps · ficha propia "${p.displayName?.text}"`,
      comoLoSupe: "la persona tiene su propio registro en Maps, distinto al de la clínica",'''
n2='''      fuente: `Google Maps · ficha propia "${p.displayName?.text}"`,
      comoLoSupe: "la persona tiene su propio registro en Maps, distinto al de la clínica",
      nombreEnLaFuente: String(p.displayName?.text ?? "").trim() || undefined,'''
assert v2 in s
s=s.replace(v2,n2,1)
io.open(p,'w',encoding='utf-8').write(s)
print("agenteTelefono.ts: HallazgoTelefono trae nombreEnLaFuente")

# ---------- 2) cascada: guardar el nombre completo y ser honesto con el fijo ----------
p2='lib/cascada.ts'
c=io.open(p2,encoding='utf-8').read()

v3='''  decisor_nombre: string | null;
  decisor_confianza: string | null;'''
n3='''  decisor_nombre: string | null;
  decisor_confianza: string | null;
  decisor_nombre_completo: string | null;'''
assert v3 in c
c=c.replace(v3,n3,1)

v4='.select("rut,razon_social,comuna,telefono,telefono_directo,decisor_nombre,decisor_confianza,prospect_id,n_trabajadores")'
n4='.select("rut,razon_social,comuna,telefono,telefono_directo,decisor_nombre,decisor_confianza,decisor_nombre_completo,prospect_id,n_trabajadores")'
assert v4 in c
c=c.replace(v4,n4,1)

v5='''  const control = (e.telefono ?? publico)
    ? ""
    : " · SIN CONTROL: no había número público con qué compararlo, puede ser la recepción";

  const { data, error } = await db()
    .from("empresas_sii")
    .update({
      telefono_directo: h.telefono,
      telefono_directo_origen: `${h.fuente} · ${h.tipo} · confianza ${h.confianza}${control}`,
      updated_at: new Date().toISOString(),
    })'''
n5='''  const control = (e.telefono ?? publico)
    ? ""
    : " · SIN CONTROL: no había número público con qué compararlo, puede ser la recepción";

  // Un FIJO encontrado en la ficha de un profesional es, casi siempre, la
  // línea de su consulta — y esa la contesta la recepcionista igual que
  // cualquier otra. Caso real (25-ago-2026): el público de la Clínica Bellolio
  // era un celular y el "directo" que hallamos, un fijo. Llamarlo `directo` a
  // secas promete más de lo que sabemos. Lo único que resuelve de quién es un
  // número es la llamada, y para eso está el campo "¿quién contestó?".
  const matiz = /^9\\d{8}$/.test(nuevo)
    ? ""
    : " · es un FIJO: probablemente la línea de su consulta, confirmar al llamar quién contesta";

  // El nombre completo que regala la fuente vale por sí solo, aunque el
  // teléfono termine descartándose: sirve para pedir por la persona correcta.
  const nombreCompleto =
    h.nombreEnLaFuente && !e.decisor_nombre_completo
      ? { decisor_nombre_completo: h.nombreEnLaFuente, decisor_nombre_completo_origen: h.fuente }
      : {};

  const { data, error } = await db()
    .from("empresas_sii")
    .update({
      telefono_directo: h.telefono,
      telefono_directo_origen: `${h.fuente} · ${h.tipo} · confianza ${h.confianza}${matiz}${control}`,
      ...nombreCompleto,
      updated_at: new Date().toISOString(),
    })'''
assert v5 in c
c=c.replace(v5,n5,1)
io.open(p2,'w',encoding='utf-8').write(c)
print("cascada.ts: guarda nombre completo y matiza el fijo")
