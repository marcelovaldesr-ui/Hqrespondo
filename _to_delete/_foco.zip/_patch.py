import io

# ---------- 1) actividades.ts: aceptar y guardar lead_foco_id ----------
p='lib/actividades.ts'
s=io.open(p,encoding='utf-8').read()
v='''export interface NuevaActividad {
  prospect_id?: string | null;'''
n='''export interface NuevaActividad {
  prospect_id?: string | null;
  /**
   * A qué lead de Foco se refiere. Sin esto la bitácora guardaba el toque pero
   * no a quién, así que reconstruir la historia de UN lead obligaba a buscar
   * por texto dentro de la nota. Migración 030.
   */
  lead_foco_id?: string | null;'''
assert v in s, "no calzo NuevaActividad"
s=s.replace(v,n,1)

v2='''    const { error } = await db().from("actividades").insert({
      prospect_id: a.prospect_id ?? null,'''
n2='''    const { error } = await db().from("actividades").insert({
      prospect_id: a.prospect_id ?? null,
      lead_foco_id: a.lead_foco_id ?? null,'''
assert v2 in s, "no calzo el insert"
s=s.replace(v2,n2,1)
io.open(p,'w',encoding='utf-8').write(s)
print("actividades.ts: acepta lead_foco_id")

# ---------- 2) /api/foco POST: pasar el lead_foco_id ----------
p2='app/api/foco/route.ts'
r=io.open(p2,encoding='utf-8').read()
v3='''    await registrarActividad({
      contacto: lead.telefono ?? "",'''
n3='''    await registrarActividad({
      lead_foco_id: lead.id,
      contacto: lead.telefono ?? "",'''
assert v3 in r, "no calzo registrarActividad en foco"
r=r.replace(v3,n3,1)

# PATCH: permitir editar el proximo paso
v4='''    if (b.recordatorio !== undefined) upd.recordatorio = b.recordatorio || null;'''
n4='''    if (b.recordatorio !== undefined) upd.recordatorio = b.recordatorio || null;
    // Próximo paso: QUÉ hacer. Va aparte del recordatorio, que dice CUÁNDO, y
    // aparte de la nota, donde un compromiso se pierde entre el relato.
    if (b.proximo_paso !== undefined) upd.proximo_paso = String(b.proximo_paso).trim().slice(0, 600) || null;
    if (b.proximo_paso_at !== undefined) upd.proximo_paso_at = b.proximo_paso_at || null;'''
assert v4 in r, "no calzo el bloque de recordatorio"
r=r.replace(v4,n4,1)
io.open(p2,'w',encoding='utf-8').write(r)
print("api/foco/route.ts: bitacora enlazada + proximo paso editable")

# ---------- 3) LeadsFoco.tsx: montar los dos componentes ----------
p3='components/LeadsFoco.tsx'
c=io.open(p3,encoding='utf-8').read()

# import
lineas=c.split("\n")
idx=None
for i,l in enumerate(lineas):
    if l.startswith("import ") or l.startswith('import{'):
        idx=i
assert idx is not None
lineas.insert(idx+1, 'import NuevoLeadFoco from "@/components/NuevoLeadFoco";')
lineas.insert(idx+2, 'import BitacoraLead from "@/components/BitacoraLead";')
c="\n".join(lineas)

# boton en la barra
v5='''            <button className="btn-ghost" onClick={() => setImportar(true)}>
              Importar CSV
            </button>'''
n5='''            <NuevoLeadFoco />
            <button className="btn-ghost" onClick={() => setImportar(true)}>
              Importar CSV
            </button>'''
assert v5 in c, "no calzo el boton Importar CSV"
c=c.replace(v5,n5,1)

# bitacora al pie de la ficha
v6='''                <div className="mt-1.5 text-center text-[10.5px] text-ink-faint">
                  Último: {lead.ultimo_resultado ? RESULTADO_CFG[lead.ultimo_resultado].label : "sin tocar"}
                  {lead.ultimo_intento ? ` · ${fechaCorta(lead.ultimo_intento)}` : ""}
                </div>'''
n6='''                <div className="mt-1.5 text-center text-[10.5px] text-ink-faint">
                  Último: {lead.ultimo_resultado ? RESULTADO_CFG[lead.ultimo_resultado].label : "sin tocar"}
                  {lead.ultimo_intento ? ` · ${fechaCorta(lead.ultimo_intento)}` : ""}
                </div>

                <BitacoraLead key={lead.id} leadId={lead.id} />'''
assert v6 in c, "no calzo el pie de la ficha"
c=c.replace(v6,n6,1)

io.open(p3,'w',encoding='utf-8').write(c)
print("LeadsFoco.tsx: boton de alta manual + bitacora en la ficha")
